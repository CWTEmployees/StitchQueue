  $(document).ready(function(){
    $('[data-toggle="tooltip"]').tooltip();   
});

$(document).ready(function () {

    $(".player").mb_YTPlayer();

});